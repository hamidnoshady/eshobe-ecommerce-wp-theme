(function() {
  const WM_FILTER_RELOAD_ONLY = false;
  let archive = document.querySelector('[data-product-archive]');
  if (!archive) {
    return;
  }

  const mobileQuery = window.matchMedia('(max-width: 767px)');
  let activeRequest = null;
  let changeTimer = null;

  function getToggle() {
    return archive ? archive.querySelector('[data-archive-filter-toggle]') : null;
  }

  function setExpanded(expanded) {
    const toggle = getToggle();
    if (toggle) {
      toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    }
  }

  function openFilters() {
    if (!archive) {
      return;
    }

    if (mobileQuery.matches) {
      archive.classList.add('is-filter-open');
      setExpanded(true);
      return;
    }

    archive.classList.remove('is-filters-collapsed');
    setExpanded(true);
  }

  function closeFilters() {
    if (!archive) {
      return;
    }

    if (mobileQuery.matches) {
      archive.classList.remove('is-filter-open');
      setExpanded(false);
      return;
    }

    archive.classList.add('is-filters-collapsed');
    setExpanded(false);
  }

  function closeMobileFilters() {
    if (!archive || !mobileQuery.matches) {
      return;
    }

    archive.classList.remove('is-filter-open');
    setExpanded(false);
  }

  function initFilterWidgets(root) {
    const filterWidgets = Array.from(root.querySelectorAll('.wm-archive-filter-widget'));

    filterWidgets.forEach(function(widget) {
      const title = widget.querySelector('.wm-archive-filter-widget__title, .widget-title');
      if (!title || title.dataset.archiveWidgetReady === 'true') {
        return;
      }

      title.dataset.archiveWidgetReady = 'true';
      title.setAttribute('role', 'button');
      title.setAttribute('tabindex', '0');
      title.setAttribute('aria-expanded', widget.classList.contains('is-collapsed') ? 'false' : 'true');

      function toggleWidget() {
        const collapsed = widget.classList.toggle('is-collapsed');
        title.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
      }

      title.addEventListener('click', toggleWidget);
      title.addEventListener('keydown', function(event) {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          toggleWidget();
        }
      });
    });
  }

  function numericValue(value) {
    const normalized = String(value || '')
      .replace(/[۰-۹]/g, function(char) {
        return String('۰۱۲۳۴۵۶۷۸۹'.indexOf(char));
      })
      .replace(/[٠-٩]/g, function(char) {
        return String('٠١٢٣٤٥٦٧٨٩'.indexOf(char));
      })
      .replace(/[^\d]/g, '');
    return normalized ? Number(normalized) : 0;
  }

  function formatNumber(value) {
    const number = numericValue(value);
    return number ? number.toLocaleString('en-US') : '';
  }

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function roundedToStep(value, step, min) {
    const numericStep = Number(step) || 1;
    const numericMin = Number(min) || 0;
    return Math.round((Number(value) - numericMin) / numericStep) * numericStep + numericMin;
  }

  function scheduleFormLoad(form, delay) {
    if (!form) {
      return;
    }

    const url = formUrl(form);
    if (!url) {
      return;
    }

    if (WM_FILTER_RELOAD_ONLY) {
      window.location.href = url.toString();
      return;
    }

    window.clearTimeout(changeTimer);
    changeTimer = window.setTimeout(function() {
      loadArchive(url, true);
    }, delay || 180);
  }

  function initPriceFilters(root) {
    root.querySelectorAll('[data-price-filter]').forEach(function(filter) {
      const minRange = filter.querySelector('[data-price-min-range]');
      const maxRange = filter.querySelector('[data-price-max-range]');
      const wrapper = filter.closest('form');
      const minInput = wrapper ? wrapper.querySelector('[data-price-min-input]') : null;
      const maxInput = wrapper ? wrapper.querySelector('[data-price-max-input]') : null;
      const step = Number(filter.dataset.priceStep) || Number(minRange && minRange.step) || 1;

      if (!minRange || !maxRange || !minInput || !maxInput || filter.dataset.priceReady === 'true') {
        return;
      }

      filter.dataset.priceReady = 'true';

      function updateTrack() {
        const min = Number(minRange.min) || 0;
        const max = Number(maxRange.max) || min + 1;
        const minValue = Number(minRange.value) || min;
        const maxValue = Number(maxRange.value) || max;
        const span = Math.max(1, max - min);

        filter.style.setProperty('--wm-price-min', String(((minValue - min) / span) * 100) + '%');
        filter.style.setProperty('--wm-price-max', String(((maxValue - min) / span) * 100) + '%');
      }

      function syncFromRange(event) {
        let minValue = Number(minRange.value);
        let maxValue = Number(maxRange.value);
        if (minValue > maxValue) {
          if (event && event.target === minRange) {
            maxValue = minValue;
            maxRange.value = String(maxValue);
          } else {
            minValue = maxValue;
            minRange.value = String(minValue);
          }
        }
        minInput.value = minValue === Number(minRange.min) ? '' : formatNumber(minValue);
        maxInput.value = maxValue === Number(maxRange.max) ? '' : formatNumber(maxValue);
        updateTrack();
      }

      function syncFromInput(scheduleAjax) {
        const minBound = Number(minRange.min) || 0;
        const maxBound = Number(maxRange.max) || minBound + 1;
        let minValue = numericValue(minInput.value) || minBound;
        let maxValue = numericValue(maxInput.value) || maxBound;

        minValue = clamp(roundedToStep(minValue, step, minBound), minBound, maxBound);
        maxValue = clamp(roundedToStep(maxValue, step, minBound), minBound, maxBound);
        if (minValue > maxValue) {
          maxValue = minValue;
        }

        minRange.value = String(minValue);
        maxRange.value = String(maxValue);
        minInput.value = minValue === minBound ? '' : formatNumber(minValue);
        maxInput.value = maxValue === maxBound ? '' : formatNumber(maxValue);
        updateTrack();
        if (scheduleAjax) {
          scheduleFormLoad(wrapper, 260);
        }
      }

      minRange.addEventListener('input', syncFromRange);
      maxRange.addEventListener('input', syncFromRange);
      minRange.addEventListener('change', function(event) {
        syncFromRange(event);
        scheduleFormLoad(wrapper, 120);
      });
      maxRange.addEventListener('change', function(event) {
        syncFromRange(event);
        scheduleFormLoad(wrapper, 120);
      });
      minRange.addEventListener('pointerup', function() {
        scheduleFormLoad(wrapper, 120);
      });
      maxRange.addEventListener('pointerup', function() {
        scheduleFormLoad(wrapper, 120);
      });
      minInput.addEventListener('change', function() {
        syncFromInput(true);
      });
      maxInput.addEventListener('change', function() {
        syncFromInput(true);
      });
      minInput.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
          event.preventDefault();
          syncFromInput(true);
        }
      });
      maxInput.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
          event.preventDefault();
          syncFromInput(true);
        }
      });
      syncFromInput();
    });
  }

  function sameOrigin(url) {
    return url.origin === window.location.origin;
  }

  function shouldHandleLink(link) {
    if (!archive || !link || link.target || link.hasAttribute('download')) {
      return false;
    }

    const url = new URL(link.href, window.location.href);
    if (!sameOrigin(url) || url.hash && url.pathname === window.location.pathname && url.search === window.location.search) {
      return false;
    }

    return Boolean(link.closest('.wm-product-archive__sort-pills, .wm-active-filters-region, .wm-shop-pagination, .wm-product-archive__sidebar'));
  }

  function formUrl(form) {
    const action = form.getAttribute('action') || window.location.href;
    const method = (form.getAttribute('method') || 'get').toLowerCase();

    if (method !== 'get') {
      return null;
    }

    const url = new URL(action, window.location.href);
    const data = new FormData(form);
    const grouped = {};

    url.search = '';
    data.forEach(function(value, key) {
      if (value !== '') {
        if (key.slice(-2) === '[]') {
          key = key.slice(0, -2);
        }
        if (key === 'min_price' || key === 'max_price') {
          value = String(numericValue(value) || '');
        }
        if (value === '') {
          return;
        }
        if (!grouped[key]) {
          grouped[key] = [];
        }
        grouped[key].push(value);
      }
    });
    Object.keys(grouped).forEach(function(key) {
      url.searchParams.set(key, grouped[key].join(','));
    });
    url.searchParams.delete('paged');
    url.searchParams.delete('yith_wcan');
    url.searchParams.delete('yith_wcan_ajax');
    url.searchParams.delete('yith_wcan_redirect');

    return url;
  }

  function isCategoryFilterField(field) {
    return field && (field.name === 'filter_product_cat' || field.name === 'filter_product_cat[]' || field.dataset.filterKey === 'filter_product_cat');
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === 'function') {
      return window.CSS.escape(value);
    }

    return String(value).replace(/["\\]/g, '\\$&');
  }

  function paramValues(params, name) {
    const names = [name];
    if (name.slice(-2) === '[]') {
      names.push(name.slice(0, -2));
    } else {
      names.push(name + '[]');
    }

    return names.reduce(function(values, currentName) {
      params.getAll(currentName).forEach(function(value) {
        String(value).split(',').forEach(function(item) {
          const normalized = item.trim();
          if (normalized !== '') {
            values.push(normalized);
          }
        });
      });
      return values;
    }, []);
  }

  function setFilterItemState(field, active) {
    const item = field.closest('.wm-archive-filter-widget li, .wm-archive-filter-widget label, .wm-archive-filter-widget .wc-layered-nav-term, .wm-archive-filter-widget .chosen, .wm-product-archive__filters li, .wm-product-archive__filters label');
    if (!item) {
      return;
    }

    item.classList.toggle('is-active', active);
    item.classList.toggle('active', active);
    item.classList.toggle('checked', active);

    if (item.hasAttribute('aria-checked')) {
      item.setAttribute('aria-checked', active ? 'true' : 'false');
    }

    if (item.hasAttribute('aria-selected')) {
      item.setAttribute('aria-selected', active ? 'true' : 'false');
    }
  }

  function cleanSidebarLoadingState(root) {
    root.classList.remove('is-loading', 'loading', 'is-skeleton', 'skeleton', 'placeholder', 'is-updating');
    root.querySelectorAll('.is-loading, .loading, .is-skeleton, .skeleton, .placeholder, .is-updating').forEach(function(item) {
      item.classList.remove('is-loading', 'loading', 'is-skeleton', 'skeleton', 'placeholder', 'is-updating');
    });
  }

  function syncSidebarInputsFromUrl(url) {
    if (!archive) {
      return;
    }

    const params = new URL(url.toString(), window.location.href).searchParams;
    const fields = archive.querySelectorAll('.wm-product-archive__sidebar input, .wm-product-archive__sidebar select, .wm-product-archive__sidebar textarea');

    fields.forEach(function(field) {
      if (!field.name) {
        return;
      }

      const values = paramValues(params, field.name);
      let active = false;

      if (field.matches('input[type="checkbox"], input[type="radio"]')) {
        active = values.indexOf(field.value) !== -1 || (field.value === 'on' && values.length > 0);
        field.checked = active;
      } else if (field.matches('select')) {
        if (field.multiple) {
          Array.from(field.options).forEach(function(option) {
            option.selected = values.indexOf(option.value) !== -1;
          });
          active = values.length > 0;
        } else {
          field.value = values.length ? values[0] : '';
          active = field.value !== '';
        }
      } else {
        field.value = values.length ? values[0] : '';
        if (field.matches('[data-price-min-input], [data-price-max-input]')) {
          field.value = formatNumber(field.value);
        }
        active = field.value !== '';
      }

      setFilterItemState(field, active);
    });
  }

  function setLoading(loading) {
    if (!archive) {
      return;
    }

    archive.classList.toggle('is-ajax-loading', loading);
    archive.setAttribute('aria-busy', loading ? 'true' : 'false');
  }

  function syncSidebarState(nextArchive) {
    const currentFields = archive.querySelectorAll('.wm-product-archive__sidebar input, .wm-product-archive__sidebar select, .wm-product-archive__sidebar textarea');
    const nextFields = nextArchive.querySelectorAll('.wm-product-archive__sidebar input, .wm-product-archive__sidebar select, .wm-product-archive__sidebar textarea');

    currentFields.forEach(function(field) {
      const selector = field.name
        ? '[name="' + cssEscape(field.name) + '"]'
        : field.id
          ? '#' + cssEscape(field.id)
          : '';
      if (!selector) {
        return;
      }

      const matches = Array.from(nextFields).filter(function(item) {
        return item.matches(selector) && (!field.value || item.value === field.value);
      });
      const nextField = matches[0];
      if (!nextField) {
        if (field.type === 'checkbox' || field.type === 'radio') {
          field.checked = false;
        } else {
          field.value = '';
        }
        return;
      }

      if (field.type === 'checkbox' || field.type === 'radio') {
        field.checked = nextField.checked;
      } else {
        field.value = nextField.value;
      }
    });
  }

  function replaceSection(selector, doc) {
    const current = archive.querySelector(selector);
    const next = doc.querySelector(selector);

    if (current && next) {
      current.replaceWith(next);
      return true;
    }

    if (selector === '.wm-active-filters-region' && current && !next) {
      return false;
    }

    if (current && !next) {
      current.remove();
      return true;
    }

    if (!current && next) {
      const main = archive.querySelector('.wm-product-archive__main');
      const pagination = archive.querySelector('.wm-shop-pagination');
      const loop = archive.querySelector('.wm-products-loop');
      const empty = archive.querySelector('.wm-product-archive__empty');
      const activeFilters = archive.querySelector('.wm-active-filters-region');
      const toolbar = archive.querySelector('.wm-shop-toolbar');

      if (selector === '.wm-active-filters-region' && toolbar) {
        toolbar.insertAdjacentElement('afterend', next);
      } else if (selector === '.wm-shop-pagination' && (loop || empty)) {
        (loop || empty).insertAdjacentElement('afterend', next);
      } else if (selector === '.wm-products-loop' && activeFilters) {
        activeFilters.insertAdjacentElement('afterend', next);
      } else if (selector === '.wm-product-archive__empty' && activeFilters) {
        activeFilters.insertAdjacentElement('afterend', next);
      } else if (main) {
        main.appendChild(next);
      } else if (pagination) {
        pagination.insertAdjacentElement('beforebegin', next);
      }
      return true;
    }

    return false;
  }

  function replaceSidebarPanel(doc) {
    const current = archive.querySelector('.wm-product-archive__filters');
    const next = doc.querySelector('.wm-product-archive__filters');

    if (!current || !next) {
      return false;
    }

    const hasControls = Boolean(next.querySelector('a[href], input, select, button, .wm-archive-filter-widget, .widget'));
    const hasSkeletonOnly = Boolean(next.querySelector('.skeleton, .is-skeleton, .placeholder, .is-loading, .loading')) && !hasControls;
    if (!hasControls || hasSkeletonOnly) {
      if (window.console && typeof window.console.warn === 'function') {
        window.console.warn('Eshobe Ecommerce archive: skipped incomplete sidebar filter response.');
      }
      cleanSidebarLoadingState(current);
      return false;
    }

    current.innerHTML = next.innerHTML;
    cleanSidebarLoadingState(current);
    initFilterWidgets(current);
    initPriceFilters(current);
    return true;
  }

  function replaceArchiveFromDocument(doc, url, pushState) {
    const nextArchive = doc.querySelector('[data-product-archive]');

    if (!nextArchive || !archive.querySelector('.wm-product-archive__main')) {
      window.location.href = url.toString();
      return;
    }

    replaceSection('.wm-shop-toolbar', doc);
    replaceSection('.wm-active-filters-region', doc);

    const hasNextLoop = Boolean(doc.querySelector('.wm-products-loop'));
    const hasNextEmpty = Boolean(doc.querySelector('.wm-product-archive__empty'));
    if (hasNextLoop) {
      replaceSection('.wm-products-loop', doc);
      replaceSection('.wm-product-archive__empty', doc);
    } else if (hasNextEmpty) {
      replaceSection('.wm-product-archive__empty', doc);
      replaceSection('.wm-products-loop', doc);
    }

    replaceSection('.wm-shop-pagination', doc);
    replaceSidebarPanel(doc);

    if (pushState) {
      window.history.pushState({ wmProductArchive: true }, '', url.toString());
    }

    syncSidebarState(nextArchive);
    syncSidebarInputsFromUrl(url);

    if (doc.title) {
      document.title = doc.title;
    }

    closeMobileFilters();
    archive.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function loadArchive(url, pushState) {
    if (!archive) {
      return;
    }

    if (activeRequest) {
      activeRequest.abort();
    }

    activeRequest = new AbortController();
    setLoading(true);

    fetch(url.toString(), {
      credentials: 'same-origin',
      signal: activeRequest.signal
    })
      .then(function(response) {
        if (!response.ok) {
          throw new Error('Archive request failed');
        }
        return response.text();
      })
      .then(function(html) {
        const doc = new DOMParser().parseFromString(html, 'text/html');
        replaceArchiveFromDocument(doc, url, pushState);
      })
      .catch(function(error) {
        if (error.name !== 'AbortError') {
          window.location.href = url.toString();
        }
      })
      .finally(function() {
        activeRequest = null;
        setLoading(false);
        if (archive) {
          cleanSidebarLoadingState(archive);
        }
      });
  }

  document.addEventListener('click', function(event) {
    const toggle = event.target.closest('[data-archive-filter-toggle]');
    if (toggle && archive && archive.contains(toggle)) {
      event.preventDefault();
      const isOpen = mobileQuery.matches
        ? archive.classList.contains('is-filter-open')
        : !archive.classList.contains('is-filters-collapsed') && !archive.classList.contains('wm-product-archive--filters-closed');

      if (isOpen) {
        closeFilters();
      } else {
        archive.classList.remove('wm-product-archive--filters-closed');
        openFilters();
      }
      return;
    }

    const closeButton = event.target.closest('[data-archive-filter-close]');
    if (closeButton && archive && archive.contains(closeButton)) {
      event.preventDefault();
      closeFilters();
      return;
    }

    const treeToggle = event.target.closest('.wm-custom-filter__tree-toggle');
    if (treeToggle && archive && archive.contains(treeToggle)) {
      event.preventDefault();
      const item = treeToggle.closest('.wm-custom-filter__option');
      const isOpen = item.classList.toggle('is-tree-open');
      treeToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      return;
    }

    const link = event.target.closest('a[href]');
    if (!link || !archive || !archive.contains(link) || !shouldHandleLink(link)) {
      return;
    }

    event.preventDefault();
    const url = new URL(link.href, window.location.href);
    url.searchParams.delete('add-to-cart');
    if (WM_FILTER_RELOAD_ONLY) {
      window.location.href = url.toString();
      return;
    }
    loadArchive(url, true);
  });

  document.addEventListener('submit', function(event) {
    const form = event.target;
    if (!archive || !archive.contains(form) || !form.closest('.wm-product-archive__sidebar')) {
      return;
    }

    const url = formUrl(form);
    if (!url) {
      return;
    }

    if (WM_FILTER_RELOAD_ONLY) {
      event.preventDefault();
      window.location.href = url.toString();
      return;
    }

    event.preventDefault();
    loadArchive(url, true);
  });

  document.addEventListener('change', function(event) {
    const field = event.target;
    if (!archive || !archive.contains(field) || !field.closest('.wm-product-archive__sidebar')) {
      return;
    }

    if (field.matches('[data-price-min-range], [data-price-max-range], [data-price-min-input], [data-price-max-input]')) {
      return;
    }

    const form = field.form;
    if (!form || !field.matches('input[type="checkbox"], input[type="radio"], input[type="number"], input[type="text"], select')) {
      return;
    }

    if (WM_FILTER_RELOAD_ONLY) {
      const url = formUrl(form);
      if (url) {
        window.location.href = url.toString();
      }
      return;
    }

    scheduleFormLoad(form, 180);
  });

  window.addEventListener('popstate', function() {
    if (WM_FILTER_RELOAD_ONLY) {
      window.location.reload();
      return;
    }
    loadArchive(new URL(window.location.href), false);
  });

  document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
      closeFilters();
    }
  });

  initFilterWidgets(archive);
  initPriceFilters(archive);
})();
