<?php
/**
 * Single Product Template.
 *
 * @package WM_Theme
 * @version 1.6.4
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

while ( have_posts() ) :
    the_post();
    global $product;

    if ( function_exists( 'WC' ) && isset( WC()->structured_data ) && $product instanceof WC_Product ) {
        WC()->structured_data->generate_product_data( $product );
    }
    ?>
    <main id="primary" class="site-main wm-single-product">
        <div <?php wc_product_class( 'wm-product-layout', $product ); ?>>
            <div class="wm-product-gallery-column">
                <?php woocommerce_breadcrumb(); ?>
                <?php woocommerce_show_product_sale_flash(); ?>
                <?php echo wm_render_product_gallery(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </div>
            <div class="wm-product-summary-column">
                <?php
                echo wm_render_product_intro(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                echo wm_render_product_specs(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                echo wm_render_product_purchase(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                ?>
            </div>
        </div>
        <div class="wm-container">
            <?php echo wm_render_product_tabs(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php echo wm_render_related_products(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php if ( function_exists( 'wm_render_block_region' ) ) { wm_render_block_region( 'single_product' ); } ?>
        </div>
        <?php echo wm_render_mobile_product_bottom_bar(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    </main>
    <?php
endwhile;

get_footer( 'shop' );
