<?php
/**
 * Custom login/register form for the my-account page.
 *
 * @package WM_Theme
 * @version 9.9.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_customer_login_form' );
?>

<section class="wm-account-page" dir="rtl">
	<div class="wm-account-page__container">
		<header class="wm-account-page__header">
			<div>
				<span class="wm-account-page__eyebrow"><?php echo esc_html__( 'پنل کاربری', 'eshobe-ecommerce' ); ?></span>
				<h1 class="wm-account-page__title"><?php echo esc_html__( 'ورود به حساب کاربری', 'eshobe-ecommerce' ); ?></h1>
			</div>
		</header>

		<div class="wm-account-content">
			<div class="woocommerce-MyAccount-content">

				<?php $wm_otp_enabled = function_exists( 'wm_technical_otp_enabled' ) && wm_technical_otp_enabled(); ?>

				<?php if ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) : ?>

				<div class="u-columns col2-set" id="customer_login">

					<div class="u-column1 col-1">

				<?php endif; ?>

						<h2><?php esc_html_e( 'Login', 'woocommerce' ); ?></h2>

						<?php if ( $wm_otp_enabled ) : ?>
							<div class="wm-login-tabs" data-wm-login-tabs>
								<button type="button" class="wm-login-tabs__button is-active" data-wm-login-tab="password"><?php echo esc_html__( 'ورود با رمز عبور', 'eshobe-ecommerce' ); ?></button>
								<button type="button" class="wm-login-tabs__button" data-wm-login-tab="otp"><?php echo esc_html__( 'ورود با کد یکبارمصرف', 'eshobe-ecommerce' ); ?></button>
							</div>
						<?php endif; ?>

						<div class="wm-login-panel" data-wm-login-panel="password">

						<form class="woocommerce-form woocommerce-form-login login" method="post" novalidate>

							<?php do_action( 'woocommerce_login_form_start' ); ?>

							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="username"><?php echo $wm_otp_enabled ? esc_html__( 'شماره موبایل', 'eshobe-ecommerce' ) : esc_html__( 'Username or email address', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
								<input type="<?php echo $wm_otp_enabled ? 'tel' : 'text'; ?>" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" autocomplete="username" inputmode="<?php echo $wm_otp_enabled ? 'numeric' : 'text'; ?>" placeholder="<?php echo $wm_otp_enabled ? '09xxxxxxxxx' : ''; ?>" value="<?php echo ( ! empty( $_POST['username'] ) && is_string( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" required aria-required="true" /><?php // @codingStandardsIgnoreLine ?>
							</p>
							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
								<input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password" required aria-required="true" />
							</p>

							<?php do_action( 'woocommerce_login_form' ); ?>

							<p class="form-row">
								<label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
									<input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span><?php esc_html_e( 'Remember me', 'woocommerce' ); ?></span>
								</label>
								<?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
								<button type="submit" class="woocommerce-button button woocommerce-form-login__submit<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="login" value="<?php esc_attr_e( 'Log in', 'woocommerce' ); ?>"><?php esc_html_e( 'Log in', 'woocommerce' ); ?></button>
							</p>
							<p class="woocommerce-LostPassword lost_password">
								<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Lost your password?', 'woocommerce' ); ?></a>
							</p>

							<?php do_action( 'woocommerce_login_form_end' ); ?>

						</form>

						</div>

						<?php if ( $wm_otp_enabled ) : ?>
							<div class="wm-login-panel" data-wm-login-panel="otp" hidden>
								<div class="wm-account-otp-cta">
									<p><?php echo esc_html__( 'کد یکبارمصرف به شماره موبایل شما ارسال می‌شود.', 'eshobe-ecommerce' ); ?></p>
									<button type="button" class="wm-account-otp-cta__button" data-wm-otp-trigger data-wm-otp-redirect="account">
										<?php echo esc_html__( 'ارسال کد یکبارمصرف', 'eshobe-ecommerce' ); ?>
									</button>
								</div>
							</div>
						<?php endif; ?>

				<?php if ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) : ?>

					</div>

					<div class="u-column2 col-2">

						<h2><?php esc_html_e( 'Register', 'woocommerce' ); ?></h2>

						<form method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?>>

							<?php do_action( 'woocommerce_register_form_start' ); ?>

							<?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>

								<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
									<label for="reg_username"><?php esc_html_e( 'Username', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
									<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" required aria-required="true" /><?php // @codingStandardsIgnoreLine ?>
								</p>

							<?php endif; ?>

							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
								<input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" required aria-required="true" /><?php // @codingStandardsIgnoreLine ?>
							</p>

							<?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>

								<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
									<label for="reg_password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
									<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" required aria-required="true" />
								</p>

							<?php else : ?>

								<p><?php esc_html_e( 'A link to set a new password will be sent to your email address.', 'woocommerce' ); ?></p>

							<?php endif; ?>

							<?php do_action( 'woocommerce_register_form' ); ?>

							<p class="woocommerce-form-row form-row">
								<?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
								<button type="submit" class="woocommerce-Button woocommerce-button button<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?> woocommerce-form-register__submit" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce' ); ?>"><?php esc_html_e( 'Register', 'woocommerce' ); ?></button>
							</p>

							<?php do_action( 'woocommerce_register_form_end' ); ?>

						</form>

					</div>

				</div>
				<?php endif; ?>

			</div>
		</div>
	</div>
</section>

<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
